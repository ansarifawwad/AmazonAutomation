import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.support.ui.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AmazonAutomation {
    public static void main(String[] args) {
        // initialize the browser
        System.setProperty("webdriver.chrome.driver", "/Users/fawwadansari/Downloads/chromedriver");
        ChromeOptions options = new ChromeOptions();
        
        WebDriver driver = new ChromeDriver(options);
        
        // open the Amazon website
        driver.get("https://www.amazon.in/");

        // search for "dress" and hit Enter
        WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
        searchBox.sendKeys("dress" + Keys.RETURN);

        // select the first product from the search results
        WebElement productLink = driver.findElement(By.cssSelector("span.a-size-base-plus a.a-link-normal"));
        productLink.click();

        // select the size (assuming there is only one size available)
        WebElement sizeButton = driver.findElement(By.name("submit.add-to-cart"));
        sizeButton.click();

        // add the product to the cart
        WebElement addToCartButton = driver.findElement(By.id("add-to-cart-button"));
        addToCartButton.click();

        // go to the cart
        WebElement cartButton = driver.findElement(By.id("nav-cart"));
        cartButton.click();

        // validate the order summary
        WebElement priceElement = new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#sc-subtotal-amount-activecart span.a-size-medium.a-color-price")));
        String price = priceElement.getText();
        
        WebElement quantityElement = new WebDriverWait(driver,Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#activeCartViewForm div.sc-subtotal.sc-subtotal-visible span.a-size-medium")));
        String quantity = quantityElement.getText();
        System.out.println("Order summary: price = " + price + ", quantity = " + quantity);
        assert price.startsWith("₹") && quantity.startsWith("1 item");

        // proceed to buy and take a screenshot of the login popup
        WebElement proceedToBuyButton = driver.findElement(By.name("proceedToBuy"));
        proceedToBuyButton.click();
        
        new WebDriverWait(driver,Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#a-page #authportal-main-section")));
        ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

        // close the browser
        driver.quit();
    }
}
